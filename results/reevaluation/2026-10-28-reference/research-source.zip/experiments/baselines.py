"""Transparent new baselines; these do not reconstruct the poster's baselines."""

import numpy as np


METHODS = ("fixed", "random", "adaptive", "sac")


class Baseline:
    def __init__(self, name, env, seed=0, gain=0.5):
        if name not in METHODS[:-1]:
            raise ValueError(f"Unknown baseline: {name}")
        self.name, self.env, self.gain = name, env, gain
        self.rng = np.random.default_rng(seed)

    def act(self, observation):
        env, n = self.env, self.env.n
        action = np.zeros(env.action_space.shape, dtype=np.float32)
        if self.name == "random":
            return self.rng.uniform(env.action_space.low, env.action_space.high).astype(np.float32)
        if self.name == "adaptive":
            # Use only the previous observation, never future decisions or hidden inventory.
            # Relative to the same N/2 participation target as the reward:
            # excess sellers -> reduce shop buy price; excess buyers -> increase sell price.
            if env.elapsed_steps:
                target = env.config.num_players / 2
                action[:-1:2] = -self.gain * env.config.price_offset * (observation[2*n:3*n] - target) / target
                action[1:-1:2] = self.gain * env.config.price_offset * (observation[3*n:4*n] - target) / target
        # Fixed and adaptive keep the initial fee; random and SAC can change it.
        return np.clip(action, env.action_space.low, env.action_space.high)
